export function init(ctx, payload) {
  ctx.importCSS("main.css");

  ctx.root.innerHTML = `
    <div class="app">
      <div class="header">
        <span class="title">Spiral</span>
        <label class="field">
          <span>Timeout (s)</span>
          <input type="number" min="1" step="1" name="timeout" />
        </label>
        <label class="field checkbox">
          <input type="checkbox" name="print_code" />
          <span>Show generated Rust</span>
        </label>
      </div>
    </div>
  `;

  const inputs = {
    timeout: ctx.root.querySelector("input[name=timeout]"),
    print_code: ctx.root.querySelector("input[name=print_code]"),
  };

  function render(fields) {
    inputs.timeout.value = fields.timeout;
    inputs.print_code.checked = fields.print_code;
  }

  render(payload.fields);

  function push(field) {
    const input = inputs[field];
    const value = input.type === "checkbox" ? input.checked : input.value;
    ctx.pushEvent("update_field", { field, value });
  }

  for (const field of Object.keys(inputs)) {
    inputs[field].addEventListener("change", () => push(field));
  }

  ctx.handleEvent("update", ({ fields }) => render(fields));

  ctx.handleSync(() => {
    const active = document.activeElement;
    if (active && ctx.root.contains(active)) {
      active.dispatchEvent(new Event("change"));
    }
  });
}
